
<?php
?>
<!---sign out modal --->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="Logout" aria-hidden="true">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
          <form id="logoutForm" method="post" class="form-horizontal" action="scripts/logout.php">
                <div class="form-group">
                    <p class="text-center">Are you sure you want to leave?</p>
                </div>
                <div class="form-group text-center">
                     <button type="submit" class="btn btn-danger center-block ">Yes</button>                   
                </div>
                <?php
                    $current_url = urlencode($url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
                    echo '<input type="hidden" name="return_url" value="'.$current_url.'" />';
                 ?>
        </form>
      </div>
    </div>

  </div>
</div>

<div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="Login" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content" id="loginModalC">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h5 class="modal-title">Sign In / Sign Up</h5>
            </div>

            <div class="modal-body">
                <!-- The form is placed inside the body of modal -->
                
                <div class="col-md-12">
                <form id="loginForm" method="post" class="form-horizontal" action="scripts/Signin_process.php">
                    <div class="form-group">
                        <label class="col-xs-3 control-label">Username</label>
                        <div class="col-xs-5">
                            <input type="text" class="form-control" name="username_log" />
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-xs-3 control-label">Password</label>
                        <div class="col-xs-5">
                            <input type="password" class="form-control" name="password_log" />
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-xs-5 col-xs-offset-3">
                            <button type="submit" class="btn btn-success">Sign In</button>
                        </div>
                    </div>
                    <?php
                    $current_url = urlencode($url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
                    echo '<input type="hidden" name="return_url" value="'.$current_url.'" />';
                    ?>
                </form>
                </div>
                <div class="col-md-12 modal-footer">
                    
                    <form id="signupform" class="form-horizontal " method="POST" action="scripts/Signup_process.php">
                    <div class="form-group"><label>Username</label><input id="username" name="username" class="form-control required" placeholder="Your username" data-placement="top" data-trigger="manual" data-content="Must be at least 3 characters long, and must only contain letters." type="text"></div>
                    <div class="form-group"><label>Password</label><input id="password" name="password" class="form-control required" placeholder="Your password" data-placement="top" data-trigger="manual" data-content="Must be at least 6 characters long, and must only contain letters." type="password"></div>
                    <div class="form-group"><label>Name</label><input id="name" name="name" class="form-control " placeholder="Your name" data-placement="top" data-trigger="manual" data-content="Must be at least 3 characters long, and must only contain letters." type="text"></div>
                    <div class="form-group"><label>Address</label><textarea id="address" name="address" class="form-control" placeholder="Your Address here.." data-placement="top" data-trigger="manual"></textarea></div>
                    <div class="form-group"><label>E-Mail</label><input id="email" name="email" class="form-control email" placeholder="email@you.com (so that we can contact you)" data-placement="top" data-trigger="manual" data-content="Must be a valid e-mail address (user@gmail.com)" type="email"></div>
                    <div class="form-group"><label>Mobile Phone</label><input id="mobilephone" name="mobilephone" class="form-control phone" placeholder="999-999-9999" data-placement="top" data-trigger="manual" data-content="Must be a valid phone number (999-999-9999)" type="text"></div>
                    <div class="form-group"><label>Work Phone</label><input id="workphone" name="workphone" class="form-control phone" placeholder="999-999-9999" data-placement="top" data-trigger="manual" data-content="Must be a valid phone number (999-999-9999)" type="text"></div>
                    <div class="form-group"><button type="submit" class="btn btn-success pull-right">Sign Up!</button> <p class="help-block pull-left text-danger hide" id="form-error">&nbsp; The form is not valid. </p></div>
                     <?php
                    $current_url = urlencode($url="http://".$_SERVER['HTTP_HOST'].rtrim(dirname($_SERVER['PHP_SELF']), '/\\').'/confirmation_signup.html');
                    echo '<input type="hidden" name="return_url" value="'.$current_url.'" />';
                    ?>
                    </form>
      
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#loginModal').formValidation({
        framework: 'bootstrap',
        excluded: ':disabled',
        icon: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            username: {
                validators: {
                    notEmpty: {
                        message: 'The username is required'
                    }
                }
            },
            password: {
                validators: {
                    notEmpty: {
                        message: 'The password is required'
                    }
                }
            }
        }
    });
});
</script>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="scripts/bootstrap.min.js"></script>
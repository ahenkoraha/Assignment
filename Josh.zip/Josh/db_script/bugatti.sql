-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 26, 2016 at 07:15 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bugatti`
--
CREATE Database bugatti;
-- --------------------------------------------------------

--
-- Table structure for table `main`
--

CREATE TABLE IF NOT EXISTS `main` (
`id` int(11) NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `lastposter` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `lastpostdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `topics` int(11) NOT NULL DEFAULT '0',
  `replies` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `main`
--

INSERT INTO `main` (`id`, `name`, `lastposter`, `lastpostdate`, `topics`, `replies`) VALUES
(1, 'welcome', 'test4', '0000-00-00 00:00:00', 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
`id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `price` decimal(10,0) DEFAULT NULL,
  `description` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `capacity` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `power` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `torque` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gearbox` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `speed` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `acceleration` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `emission` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fuel` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `description`, `capacity`, `power`, `torque`, `gearbox`, `speed`, `acceleration`, `emission`, `fuel`, `image`) VALUES
(1, 'VEYRON', '100000', 'Since its launch in 2005, the Bugatti Veyron has been regarded as a supercar of superlative quality. It was a real challenge for developers to fulfil the specifications that the new supercar was supposed to meet: over 1,000 hp, a top speed of over 400 km/h and the ability to accelerate from 0 to 100 in under three seconds. Even experts thought it was impossible to achieve these performance specs on the road. But that was not all.', '7993 cm³', '736 kW ( 1 001 HP) at 6 000 rpm', '1 250 Nm at 2 200-5 500 rpm', '7-speed DSG', '407 km/h', '0 – 100 km/h 2.5 sec; 0 – 200 km/h 7.3 sec; 0 – 300 km/h 16.7 sec', ' In town 999 g/km; Extra-urban 373 g/km; Combined 596 g/km', 'In town 41.9 l; Out of town 15.6 l; Combined 24.9 l; Fuel type Super unleaded 98 RON/ROZ', 'images/csm_03_bugatti-vgt_racing_web_e388ab7263.jpg'),
(2, 'SUPER SPORT', '150000', 'Bugatti continued the brand tradition of developing Super Sport versions of successful models with the Veyron 16.4 Super Sport. The Veyron 16.4 Super Sport expanded the limits of possibility in the automotive sector even further and set new benchmarks', '7993 cm³', '1,200 hp', '1,500 Nm', '7-speed DSG', '415 km/h', '0 to 100 km/h in 2.5 seconds', 'In town 867 g/km; Extra-urban 348 g/km; Combined 539 g/km', 'In town 37.2 l; Out of town 14.9 l; Combined 23.1 l; Fuel type Super unleaded 98 RON/ROZ', 'images/02_bugatti-vgt_photo_ext_web-932x524.jpg'),
(3, 'VITESSE', '170000', 'Since its launch in 2005, the Bugatti Vitesse has been regarded as a supercar of superlative quality. It was a real challenge for developers to fulfil the specifications that the new supercar was supposed to meet: over 1,000 hp, a top speed of over 400 km/h and the ability to accelerate from 0 to 100 in under three seconds. Even experts thought it was impossible to achieve these performance specs on the road. But that was not all.', '7993 cm³', '736 kW ( 1 001 HP) at 6 000 rpm', '1 250 Nm at 2 200-5 500 rpm', '7-speed DSG', '407 km/h', '0 – 100 km/h 2.5 sec; 0 – 200 km/h 7.3 sec; 0 – 300 km/h 16.7 sec', ' In town 999 g/km; Extra-urban 373 g/km; Combined 596 g/km', 'In town 41.9 l; Out of town 15.6 l; Combined 24.9 l; Fuel type Super unleaded 98 RON/ROZ', 'images/th.jpg'),
(4, 'GRAND SPORT', '250000', 'Bugatti continued the brand tradition of developing Grand Sport versions of successful models with the Veyron 16.4 Super Sport. The Veyron 16.4 Super Sport expanded the limits of possibility in the automotive sector even further and set new benchmarks', '7993 cm³', '1,200 hp', '1,500 Nm', '7-speed DSG', '415 km/h', '0 to 100 km/h in 2.5 seconds', 'In town 867 g/km; Extra-urban 348 g/km; Combined 539 g/km', 'In town 37.2 l; Out of town 14.9 l; Combined 23.1 l; Fuel type Super unleaded 98 RON/ROZ', 'images/bugatti-vision-gt-iaa-4358x202.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `replies`
--

CREATE TABLE IF NOT EXISTS `replies` (
`id` int(11) NOT NULL,
  `topicid` int(11) NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `subject` text COLLATE utf8_unicode_ci NOT NULL,
  `poster` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `topics`
--

CREATE TABLE IF NOT EXISTS `topics` (
`id` int(11) NOT NULL,
  `forumid` int(11) NOT NULL,
  `message` text COLLATE utf8_unicode_ci,
  `subject` text COLLATE utf8_unicode_ci NOT NULL,
  `poster` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastposter` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastpostdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `replies` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `topics`
--

INSERT INTO `topics` (`id`, `forumid`, `message`, `subject`, `poster`, `date`, `lastposter`, `lastpostdate`, `replies`) VALUES
(1, 1, 'rest', 'test', 'test4', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 0),
(2, 1, 'rest', 'test', 'test4', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(11) NOT NULL,
  `username` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobilephone` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `workphone` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registereddate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `name`, `email`, `address`, `mobilephone`, `workphone`, `registereddate`) VALUES
(2, 'test', 'ac250e4a00ff3144ae7689f0d23e8b26d06aa929', 'Test', 'test@mail.com', 'test', '3333695623', '3336995269', '2016-04-23 22:48:08'),
(3, 'test2', 'Password1', 'test2', 'test@mail.com', 'testing', '3333695623', '3336995269', '2016-04-23 22:53:00'),
(4, 'test4', 'ac250e4a00ff3144ae7689f0d23e8b26d06aa929', 'try', '', '', '3333695623', '', '2016-04-23 23:47:32'),
(5, 'root', '70ccd9007338d6d81dd3b6271621b9cf9a97ea00', 'test5', '', '', '', '', '2016-04-24 00:26:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `main`
--
ALTER TABLE `main`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `replies`
--
ALTER TABLE `replies`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `topics`
--
ALTER TABLE `topics`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `main`
--
ALTER TABLE `main`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `replies`
--
ALTER TABLE `replies`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `topics`
--
ALTER TABLE `topics`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

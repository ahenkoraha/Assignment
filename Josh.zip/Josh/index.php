<?php
    /*** begin our session ***/

?>
<!DOCTYPE html>
<html class="html" lang="en-US">
 <?php
 require 'function.php';
 $pagename = 'index.php';
 
  include 'head.php';
 ?>
 <body>

  <div class="clearfix" id="page"><!-- column -->
   <div class="position_content" id="page_position_content">
    <div class="browser_width colelem" id="u2059-bw">
     <div class="museBGSize" id="u2059"><!-- simple frame --></div>
    </div>
    <div class="browser_width colelem" id="u1126-bw">
       <?php include 'nav.php'; ?>
    </div>
    <div class="clearfix colelem" id="ppu2127"><!-- group -->
     <div class="grpelem" id="pu2127"><!-- inclusion -->
      <div id="u2127"><!-- simple frame --></div>
      <div class="clearfix" id="pu2129"><!-- column -->
       <!-- m_editable region-id="editable-static-tag-U2129" template="index.html" data-type="image" -->
       <div class="clip_frame colelem" id="u2129" data-muse-uid="U2129" data-muse-type="img_frame"><!-- image -->
        <img class="block" id="u2129_img" src="images/csm_03_bugatti-vgt_racing_web_e388ab7263334x188.jpg" alt="" width="333" height="188" data-muse-src="images/csm_03_bugatti-vgt_racing_web_e388ab7263334x188.jpg"/>
       </div>
       <!-- /m_editable -->
       <!-- m_editable region-id="editable-static-tag-U2136" template="index.html" data-type="image" -->
       <div class="clip_frame colelem" id="u2136" data-muse-uid="U2136" data-muse-type="img_frame"><!-- image -->
        <img class="block" id="u2136_img" src="images/csm_03_bugatti-vgt_racing_web_e388ab7263334x189.jpg" alt="" width="334" height="188" data-muse-src="images/csm_03_bugatti-vgt_racing_web_e388ab7263334x189.jpg"/>
       </div>
       <!-- /m_editable -->
       <!-- m_editable region-id="editable-static-tag-U2128" template="index.html" data-type="html" data-ice-options="disableImageResize,link" -->
       <div class="Text_Simple clearfix colelem" id="u2128-4" data-muse-uid="U2128" data-muse-type="txt_frame"><!-- content -->
        <p>The death of Ettore Bugatti in 1947 proved to be the end for the marque, and the death of his son Jean Bugatti in 1939 ensured there was not a successor to lead the factory. No more than about 8,000 cars were made. The company</p>
       </div>
       <!-- /m_editable -->
      </div>
     </div>
     <div class="grpelem" id="pu2125"><!-- inclusion -->
      <div id="u2125"><!-- simple frame --></div>
      <div class="clearfix" id="pu2126-5"><!-- group -->
       <!-- m_editable region-id="editable-static-tag-U2126" template="index.html" data-type="html" data-ice-options="disableImageResize,link" -->
       <div class="Text_Simple clearfix grpelem" id="u2126-5" data-muse-uid="U2126" data-muse-type="txt_frame"><!-- content -->
        <p id="u2126-3"><span id="u2126">Automobiles Ettore Bugatti was a French car manufacturer of high-performance automobiles, founded in 1909 in the then German city of Molsheim, Alsace by Italian-born Ettore Bugatti. Bugatti cars were known for their design beauty (Ettore Bugatti was from a family of artists and considered himself to be both an artist and constructor) and for their many race victories.</span><span id="u2126-2"></span></p>
       </div>
       <!-- /m_editable -->
      </div>
     </div>
     <!-- m_editable region-id="editable-static-tag-U2119" template="index.html" data-type="image" -->
     <div class="clip_frame grpelem" id="u2119" data-muse-uid="U2119" data-muse-type="img_frame"><!-- image -->
      <img class="block" id="u2119_img" src="images/bugatti-vision-gt-iaa-4.jpg" alt="" width="701" height="394" data-muse-src="images/bugatti-vision-gt-iaa-4.jpg"/>
     </div>
     <!-- /m_editable -->
    </div>
    <div class="verticalspacer"></div>
   </div>
  </div>
  <!-- JS includes -->
  <?php include 'footer.php' ?>
   </body>
</html>

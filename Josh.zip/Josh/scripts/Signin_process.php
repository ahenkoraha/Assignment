<?php

/*** begin our session ***/
//session_start();
if (!isset($_SESSION)) {
    session_start();
}

require_once 'db_config.php';
global $mysql_hostname, $mysql_dbname, $mysql_username,$mysql_password;

/*** check if the users is already logged in ***/
if(isset( $_SESSION['user_id'] ))
{
    $message = 'Users is already logged in';
}
/*** check that both the username, password have been submitted ***/
if(!isset( $_POST['username_log'], $_POST['password_log']))
{
    $message = 'Please enter a valid username and password';
}
/*** check the username is the correct length ***/
elseif (strlen( $_POST['username_log']) > 20 || strlen($_POST['username_log']) < 3)
{
    $message = 'Incorrect Length for Username';
}
/*** check the password is the correct length ***/
elseif (strlen( $_POST['password_log']) > 20 || strlen($_POST['password_log']) < 6)
{
    $message = 'Incorrect Length for Password';
}

/*** check the password has only alpha numeric characters ***/
elseif (ctype_alnum($_POST['password_log']) != true)
{
        /*** if there is no match ***/
        $message = "Password must be alpha numeric";
}
else
{
    /*** if we are here the data is valid and we can insert it into database ***/
    $username_log = filter_var($_POST['username_log'], FILTER_SANITIZE_STRING);
    $password_log = filter_var($_POST['password_log'], FILTER_SANITIZE_STRING);

    /*** now we can encrypt the password ***/
    $password_log = sha1( $password_log );
   

    try
    {
        $dbh = new PDO("mysql:host=$mysql_hostname;dbname=$mysql_dbname", $mysql_username, $mysql_password);
        /*** $message = a message saying we have connected ***/

        /*** set the error mode to excptions ***/
        $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        /*** prepare the select statement ***/
        $stmt = $dbh->prepare("SELECT id, username,password FROM users 
                    WHERE username = :username_log AND password = :password_log");

        /*** bind the parameters ***/
        $stmt->bindParam(':username_log', $username_log, PDO::PARAM_STR);
        $stmt->bindParam(':password_log', $password_log, PDO::PARAM_STR, 40);

        /*** execute the prepared statement ***/
        $stmt->execute();

        /*** check for a result ***/
        $user_id = $stmt->fetchColumn();
       

        /*** if we have no result then fail boat ***/
        if($user_id == false)
        {
                $message = 'Login Failed';
        }
        /*** if we do have a result, all is well ***/
        else
        {
                /*** set the session user_id and user_name variable ***/
                $_SESSION['user_id'] = $user_id;
                $_SESSION['user_name'] = $username_log;

                /*** tell the user we are logged in ***/
                //$message = 'You are now logged in';
        }


    }
    catch(Exception $e)
    {
        /*** if we are here, something has gone wrong with the database ***/
        $message = 'We are unable to process your request. Please try again later"';
    }
}
//back to return url

    $return_url = (isset($_POST["return_url"]))?urldecode($_POST["return_url"]):''; //return url
//if (!isset($message)) {
    header('Location:'.$return_url);
/*}
else {
    $return_url = urlencode($url="http://".$_SERVER['HTTP_HOST'].rtrim(dirname($_SERVER['PHP_SELF']), '/\\').'/index.php');
}*/
?>

<html>
<head>
    <title>Login Error</title>
</head>
<p><span class="fa fa-info-circle" aria-hidden="true"></span><h2 class="alert alert-warning"><?php echo $message; 
 ?></p>
 <p> Please <a href="<?php $return_url?>">sign in</a> again!</h2></p>
</body>
</html>
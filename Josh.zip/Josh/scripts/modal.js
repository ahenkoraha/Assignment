$(document).ready(function() {
    $('#first').on('click', function() {
        $('#myModal').modal();
    });
 });
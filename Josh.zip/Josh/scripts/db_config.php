<?php


   /*** connect to database ***/
    /*** mysql hostname ***/
    $mysql_hostname = 'localhost';

    /*** mysql username ***/
    $mysql_username = 'root';

    /*** mysql password ***/
    $mysql_password = 'Password1';
    

    /*** database name ***/
    $mysql_dbname = 'bugatti';
    
    $currency ="$";
    $shipping_cost      = 1.50; //shipping cost
    $taxes              = array( //List your Taxes percent here.
                            'VAT' => 12,
                            'Service Tax' => 5
                            ); 
    
    /***connection      ***/              
    $mysqli = new mysqli($mysql_hostname, $mysql_username, $mysql_password,$mysql_dbname);                       
    if ($mysqli->connect_error) {
        die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
    }
?>
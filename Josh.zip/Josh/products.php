<?php
 include_once('scripts/db_config.php');
?>
<!DOCTYPE html>
<html class="html" lang="en-US">
   <?php
 require 'function.php';
 $pagename = 'products.php'; 
  include 'head.php';
 ?>
 <body>
      </div>
       <?php include 'nav.php'; ?>
      </div>
     
 <div class="p-container col-md-8 ">
<?php
$current_url = urlencode($url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);

$results = $mysqli->query("SELECT id, name, price, image FROM products ORDER BY id ASC");
if($results){
$products_item = '<div class="p-wrapper">';
//fetch results set as object and output HTML
while($obj = $results->fetch_object())
{
$products_item .= <<<EOT
    <div class="product col-md-4 ">
    <form method="post" action="scripts/update_shopping_cart.php">
    <div class="product-thumb thumbnail"><img src="{$obj->image}" class="img-responsive" alt="Responsive image"></div>
    <div class="product-info caption">
    
    <div class="product-content"><a href="product_detail.php?id={$obj->id}">{$obj->name}</a> </div>
    <span><strong>Price </strong></span> {$currency}{$obj->price}  
    
    <div> 
    <label>
        <span>Color</span>
        <select name="product_color">
        <option value="Black">Black</option>
        <option value="Silver">Silver</option>
        </select>
    </label>
   </div>
   <div>
    <label>
        <span>Quantity</span>
        <input  class="qborder" type="textbox"  size="2" maxlength="2" name="product_qty" value="1" />
    </label>
   </div>
    
    <input type="hidden" name="product_id" value="{$obj->id}" />
    <input type="hidden" name="type" value="add" />
    <input type="hidden" name="return_url" value="{$current_url}" />
    </div>
EOT;
if ( isset( $_SESSION['user_id'] ) )
{
   $products_item .='<div align="right">';
   $products_item .=    ' <button type="submit" class="add_to_cart btn btn-danger ">Add to Cart<span class="fa fa-shopping-cart" aria-hidden="true"></span></button></div>';
    
    
}
  $products_item .=  ' </form>';
     $products_item .='</div>';
}
$products_item .= '</div>';
echo $products_item;
}
?>
</div>

<!--Shopping cart -->
<div class="shopping-cart col-md-4">
<h2 class="lead text-center"><span class="fa fa-shopping-cart" aria-hidden="true"></span>Your Shopping Cart</h2>
<?php
if( isset( $_SESSION['user_id'] ) )
{
    if(isset($_SESSION["cart_products"]) && count($_SESSION["cart_products"])>0)
    {
        echo '<div class="cart-view-table-front" id="view-cart">';
        echo '<form method="post" action="scripts/update_shopping_cart.php">';
        echo '<table width="100%"  cellpadding="6" cellspacing="0" class="table table-striped">';
        echo '<tbody>';

        $total =0;
        $b = 0;
        foreach ($_SESSION["cart_products"] as $cart_itm)
        {
            $product_name = $cart_itm["product_name"];
            $product_qty = $cart_itm["product_qty"];
            $product_price = $cart_itm["product_price"];
            $product_id = $cart_itm["product_id"];
            $product_color = $cart_itm["product_color"];
            echo '<tr >';
            echo '<td>Qty <input class="qborder" type="text" size="2" maxlength="2" name="product_qty['.$product_id.']" value="'.$product_qty.'" /></td>';
            echo '<td>'.$product_name.'</td>';
            echo '<td><input type="checkbox" name="remove_id[]" value="'.$product_id.'" /> Remove</td>';
            echo '</tr>';
            $subtotal = ($product_price * $product_qty);
            $total = ($total + $subtotal);
        }
        echo '<td colspan="3">';
        echo '<button class="btn btn-danger" type="submit"><span class="fa fa-pencil" aria-hidden="true"></span> Update</button><a id="cartview" href="view_cart.php" class="button btn btn-danger"><span class="fa fa-arrow-right" aria-hidden="true"></span>Checkout</a>';
        echo '</td>';
        echo '</tbody>';
        echo '</table>';
    
        $current_url = urlencode($url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
        echo '<input type="hidden" name="return_url" value="'.$current_url.'" />';
        echo '</form>';
        echo '</div>';

    }
    else {
    echo '<div class="alert alert-warning">';
    echo '<h4>Shopping Cart is empty!</h4>';
    echo '</div>';
    }
}
else{
    echo '<div class="alert alert-danger">';
    echo '<h4 >Sign in to view cart</h4>';
    echo '</div>';
}
?>
</div>
     
    <?php include 'footer.php' ?>
 </body>
 </html>
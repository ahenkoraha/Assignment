<?php
	include_once 'scripts/db_config.php';
	global $mysql_hostname, $mysql_dbname, $mysql_username,$mysql_password;
?>
<!DOCTYPE html>
<html class="html" lang="en-US">
   <?php
 require 'function.php';
 $pagename = 'forum.php'; 
  include 'head.php';
 ?>
 <body>
      </div>
       <?php include 'nav.php'; ?>
      </div>
<div class="lead">
	<h1 class="text-left"><strong>Discussion Forum</strong></h1>
</div>	  
<div class=" col-md-8 col-lg-8">
	<table class="table table-hover" border="1" cellpadding="4" width="100%">
	<thead>
	<tr>
	<td>Forum</td>
	<td>Number of Topics</td>
	<td>Number of Replies</td>
	<td>Last Poster</td>
	</tr>
	</thead>
<?php
if ( isset( $_SESSION['user_id'] ) ){
	$query1 = $mysqli->query("SELECT * FROM main ORDER BY id DESC");
	if ($query1) {

		while ($output1 = $query1->fetch_assoc())
			{
				echo '<tr>';
				echo '<td><a href="topics.php?id='.$output1['id'].'">'.$output1['name'].'</a></td>';
				echo '<td><span class="badge text-center">'.$output1['topics'].'</span></td>';
				echo '<td><span class="badge text-center">'.$output1['replies'].'</span></td>';
				if (empty($output1['lastposter']))
					echo '<td>No Posts</td>';
				else
					echo '<td>'.$output1['lastposter'].' @ '.date('d-m-y G:i', $output1['lastpostdate']).'</td>';
				echo'</tr>';
			}
	}
}
else {
	echo '<tr class="alert alert-danger">';
	echo '<td colspan=4>members only page! please sign in</td>';
	echo '</tr>';
}
?>
</table>
</div>
  <?php include 'footer.php' ?>
 </body>
 </html>
<?php
 include_once('scripts/db_config.php');
?>
<!DOCTYPE html>
<html class="html" lang="en-US">
   <?php
 require 'function.php';
 $pagename = 'product_detail.php'; 
  include 'head.php';
 ?>
 <body>
      </div>
       <?php include 'nav.php'; ?>
      </div>
     <?php
        $product_id= filter_var($_GET['id'], FILTER_SANITIZE_STRING);
        $current_url = urlencode($url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);

        //we need to get product information from database.
        $results = $mysqli->prepare("SELECT id, name, price, image,description,capacity,power,torque,gearbox,speed,acceleration,emission,fuel FROM products WHERE id=? LIMIT 1 ");
        $results->bind_param('s', $product_id);
        $results->execute();
        $results->bind_result($id, $name,$price, $image,$description,$capacity,$power,$torque,$gearbox,$speed,$acceleration,$emission,$fuel);
        if($results){
            
          while($obj = $results->fetch())
            {
            //$products_detail .= <<<EOT
            echo'<div class="container">';
              echo '<div class="panel panel-danger col-md-6">';
                echo '<div class="panel-heading">';
                 echo '   <h3 class="panel-title">'.$name.'</div></h3>';
                echo '<div class="panel-body">';
                   echo ' <div>';
                   echo ' <img src="'.$image.'" class="img-responsive" alt="Responsive image">';
                    echo '</div>';
                    echo '<div class="caption">';
                    echo '<div><h3 class="text-left lead">Description</h3></div>';
                    echo '<div>';
                      echo '<p>'.$description.'</p></div>';
                      echo '</div></div></div>';
                      
                 echo '<div class="panel panel-danger col-md-6">';
                echo '<div class="panel-heading">';
                    echo '<h3 class="panel-title"><span class="fa fa-wrench" aria-hidden="true"></span>Technical Details</h3>';
               echo ' </div>';
                echo '<ul class="list-group">';
                echo '<li class="list-group-item">Cylinder capacity : '.$capacity.'</li>';
                echo '<li class="list-group-item">Power output : '.$power.'</li>';
                echo '<li class="list-group-item">Max. torque : '.$torque.'</li>';
                echo '<li class="list-group-item">Gearbox : '.$gearbox.'</li>';
                echo '<li class="list-group-item">Top speed : '.$speed.'</li>';
                echo '<li class="list-group-item">Acceleration : '.$acceleration.'</li>';
                echo '<li class="list-group-item">CO2 Emission : '.$emission.'</li>';
                echo '<li class="list-group-item">Fuel Consumption & Type : '.$fuel.'</li>';

           echo ' </ul>';

                echo '</div>';
 
            }
      
       
        }
     ?>
     
    </div>  
  <?php include 'footer.php' ?>
 </body>
</html> 
<?php
ob_start();
$id = (int) $_GET['id'];
if ($id < 1)
{
	header('Location: forum.php');
	exit();
}
ob_end_clean();

	include_once 'scripts/db_config.php';
	global $mysql_hostname, $mysql_dbname, $mysql_username,$mysql_password;
?>
<!DOCTYPE html>
<html class="html" lang="en-US">
   <?php
 require 'function.php';
 $pagename = 'topics.php'; 
  include 'head.php';
 ?>
 <body>
      </div>
       <?php include 'nav.php'; ?>
      </div>
<?php
$query2 = $mysqli->query("SELECT * FROM main ORDER BY id DESC");
if($query2){
	$output1 = $query2->fetch_assoc();
	echo '<h2 class="lead alert-danger"><strong>'.$output1['name'].'</strong></h2>';
	}
?>

<div class="col-md-8 col-lg-8">
<table class="table table-hover" border="1" cellpadding="4" width="100%">
	<thead>
<tr>
<td>Topic</td>
<td>Made by</td>
<td>Date</td>
<td>Last poster</td>
<td>Replies</td>
</tr>
</thead>
<?php
$query2 = $mysqli->query("SELECT * FROM topics WHERE forumid = '$id' ORDER BY id DESC");
if ($query2){
	$query3 =$query2->num_rows;
}
else{
	$query3=0;
}
if ($query3 == 0)
	echo '<td colspan="5">No Topics</td>';
else
{
	while ($output2 = $query2->fetch_assoc())
	{
		echo '<tr>';
		echo '<td><a href="replies.php?id='.$output2['id'].'">'.$output2['subject'].'</a></td>';
		echo '<td>'.$output2['poster'].'</td>';
		echo '<td>'.date('d-m-Y',$output2['date']).'</td>';
		if(empty($output2['lastposter']))
			echo '<td colspan="2">No replies</td>';
		else
		{
			echo '<td>'.$output2['lastposter'].' @ '.date('d-m-Y',$output2['lastpostdate']).'</td>';
			echo '<td>'.$output2['replies'].'</td>';
		}
		echo '</tr>';
	}
}
?>
</table>
</div>


<div class="container col-md-4 col-lg-4">
<form class="form-default" role="form" name="form1" id="form1" method="post" action="forum_post.php?type=topics&id=<?php echo ''.$id.''; ?>">
<h3 class="lead"><strong>Add Topic</strong></n3>
<div class=" form-group row formitem">
	<label class="form-control-label">Topic name:</label>
<input class="form-control " name="subject" id="subject" type="text" placeholder="Topic name" /></div>
<div class=" form-group row formitem">
	<label class="form-control-label">Message:</label>
<textarea class="form-control " name="message" id="message" cols="30" rows="3" placeholder="Message"></textarea></div>
<div class=" form-group row formitem">
	<label class="form-control-label">Posting by:</label>
<input class="form-control " name="poster" id="poster" type="text" readonly="readonly" placeholder="Username" value="<?php  if( isset( $_SESSION['user_name'] ) ){ echo $_SESSION['user_name'];} else {
	echo '';
} ?>" /></div>
<div class=" form-group row formitem">
<input class="btn btn-danger" type="submit" name="submit" id="submit" value="Submit" /></div>
</form>
</div>
</body>
</html>
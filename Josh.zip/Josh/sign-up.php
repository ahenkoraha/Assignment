<!DOCTYPE html>
<html class="html" lang="en-US">
  <?php 
  require 'function.php';
  $pagename = 'sign-up.php';
  include 'head.php';
 ?>
 <body>

  <div class="clearfix" id="page"><!-- column -->
   <div class="position_content" id="page_position_content">
    <div class="browser_width colelem" id="u2059-bw">
     <div id="u2059"><!-- simple frame --></div>
    </div>
    <div class="browser_width colelem" id="u1126-bw">
     <div id="u1126"><!-- group -->
      <div class="clearfix" id="u1126_align_to_page">
       <div class="clearfix grpelem" id="u2072-4"><!-- content -->
        <p>BUGATTI</p>
       </div>
       <!-- m_editable region-id="editable-static-tag-U2198" template="sign-up.html" data-type="html" data-ice-options="disableImageResize,link" -->
       <div class="clearfix grpelem" id="u2198-4" data-muse-uid="U2198" data-muse-type="txt_frame"><!-- content -->
        <p>: REGISTER</p>
       </div>
       <!-- /m_editable -->
              <?php
              
              include 'nav.php'; 
              ?>

      </div>
     </div>
    </div>
    <div class="verticalspacer"></div>
    <div class="clearfix grpelem">
      <label fld-label actAsDiv Subtitle clearfix grpelem NoWrap>Already have an Account? <button class="btn btn-default" data-toggle="modal" data-target="#loginModal">Sign In</button> here! </label>
      </div>
    
    <form class="form-grp clearfix colelem" id="widgetu2086" method="post" enctype="multipart/form-data" action="scripts/form-u2086.php"><!-- none box -->
     <div class="fld-grp clearfix grpelem" id="widgetu2094" data-required="true"><!-- none box -->
      <!-- m_editable region-id="editable-static-tag-U2097" template="sign-up.html" data-type="html" data-ice-options="disableImageResize,link" -->
      <label class="fld-label actAsDiv Subtitle clearfix grpelem" id="u2097-4" data-muse-uid="U2097" data-muse-type="txt_frame" for="widgetu2094_input"><!-- content --><span class="actAsPara">Name</span></label>
      <!-- /m_editable -->
      <!-- m_editable region-id="editable-static-tag-U2095" template="sign-up.html" data-type="html" data-ice-options="disableImageResize,link" -->
      <span class="fld-input NoWrap actAsDiv Subtitle clearfix grpelem" id="u2095-3" data-muse-uid="U2095" data-muse-type="txt_frame"><!-- content --><input class="wrapped-input" type="text" spellcheck="false" id="widgetu2094_input" name="custom_U2094" tabindex="1"/></span>
      <!-- /m_editable -->
     </div>
     <div class="fld-grp clearfix grpelem" id="widgetu2102" data-required="true" data-type="email"><!-- none box -->
      <!-- m_editable region-id="editable-static-tag-U2104" template="sign-up.html" data-type="html" data-ice-options="disableImageResize,link" -->
      <label class="fld-label actAsDiv Subtitle clearfix grpelem" id="u2104-4" data-muse-uid="U2104" data-muse-type="txt_frame" for="widgetu2102_input"><!-- content --><span class="actAsPara">Email</span></label>
      <!-- /m_editable -->
      <!-- m_editable region-id="editable-static-tag-U2105" template="sign-up.html" data-type="html" data-ice-options="disableImageResize,link" -->
      <span class="fld-input NoWrap actAsDiv Subtitle clearfix grpelem" id="u2105-3" data-muse-uid="U2105" data-muse-type="txt_frame"><!-- content --><input class="wrapped-input" type="text" spellcheck="false" id="widgetu2102_input" name="Email" tabindex="2"/></span>
      <!-- /m_editable -->
     </div>
     <!-- m_editable region-id="editable-static-tag-U2110" template="sign-up.html" data-type="html" data-ice-options="disableImageResize,link" -->
     <div class="Subtitle clearfix grpelem" id="u2110-4" data-muse-uid="U2110" data-muse-type="txt_frame"><!-- content -->
      <p>Submitting Form...</p>
     </div>
     <!-- /m_editable -->
     <!-- m_editable region-id="editable-static-tag-U2088" template="sign-up.html" data-type="html" data-ice-options="disableImageResize,link" -->
     <div class="Subtitle clearfix grpelem" id="u2088-4" data-muse-uid="U2088" data-muse-type="txt_frame"><!-- content -->
      <p>The server encountered an error.</p>
     </div>
     <!-- /m_editable -->
     <!-- m_editable region-id="editable-static-tag-U2093" template="sign-up.html" data-type="html" data-ice-options="disableImageResize,link" -->
     <div class="Subtitle clearfix grpelem" id="u2093-4" data-muse-uid="U2093" data-muse-type="txt_frame"><!-- content -->
      <p>Form received.</p>
     </div>
     <!-- /m_editable -->
     <input class="submit-btn NoWrap grpelem" id="u2087-17" type="submit" value="" tabindex="6"/><!-- state-based BG images -->
     <div class="fld-grp clearfix grpelem" id="widgetu2106" data-required="true"><!-- none box -->
      <!-- m_editable region-id="editable-static-tag-U2108" template="sign-up.html" data-type="html" data-ice-options="disableImageResize,link" -->
      <label class="fld-label actAsDiv Subtitle clearfix grpelem" id="u2108-4" data-muse-uid="U2108" data-muse-type="txt_frame" for="widgetu2106_input"><!-- content --><span class="actAsPara">Mobile No.</span></label>
      <!-- /m_editable -->
      <!-- m_editable region-id="editable-static-tag-U2109" template="sign-up.html" data-type="html" data-ice-options="disableImageResize,link" -->
      <span class="fld-input NoWrap actAsDiv Subtitle clearfix grpelem" id="u2109-3" data-muse-uid="U2109" data-muse-type="txt_frame"><!-- content --><input class="wrapped-input" type="text" spellcheck="false" id="widgetu2106_input" name="custom_U2106" tabindex="3"/></span>
      <!-- /m_editable -->
     </div>
     <div class="fld-grp clearfix grpelem" id="widgetu2098" data-required="false"><!-- none box -->
      <!-- m_editable region-id="editable-static-tag-U2100" template="sign-up.html" data-type="html" data-ice-options="disableImageResize,link" -->
      <label class="fld-label actAsDiv Subtitle clearfix grpelem" id="u2100-4" data-muse-uid="U2100" data-muse-type="txt_frame" for="widgetu2098_input"><!-- content --><span class="actAsPara">Work Phone</span></label>
      <!-- /m_editable -->
      <!-- m_editable region-id="editable-static-tag-U2099" template="sign-up.html" data-type="html" data-ice-options="disableImageResize,link" -->
      <span class="fld-input NoWrap actAsDiv Subtitle clearfix grpelem" id="u2099-3" data-muse-uid="U2099" data-muse-type="txt_frame"><!-- content --><input class="wrapped-input" type="text" spellcheck="false" id="widgetu2098_input" name="custom_U2098" tabindex="4"/></span>
      <!-- /m_editable -->
     </div>
     <div class="fld-grp clearfix grpelem" id="widgetu2089" data-required="false"><!-- none box -->
      <!-- m_editable region-id="editable-static-tag-U2090" template="sign-up.html" data-type="html" data-ice-options="disableImageResize,link" -->
      <label class="fld-label actAsDiv Subtitle clearfix grpelem" id="u2090-4" data-muse-uid="U2090" data-muse-type="txt_frame" for="widgetu2089_input"><!-- content --><span class="actAsPara">Address</span></label>
      <!-- /m_editable -->
      <!-- m_editable region-id="editable-static-tag-U2091" template="sign-up.html" data-type="html" data-ice-options="disableImageResize,link" -->
      <span class="fld-input NoWrap actAsDiv Subtitle clearfix grpelem" id="u2091-3" data-muse-uid="U2091" data-muse-type="txt_frame"><!-- content --><input class="wrapped-input" type="text" spellcheck="false" id="widgetu2089_input" name="custom_U2089" tabindex="5"/></span>
      <!-- /m_editable -->
     </div>
    </form>
    </div>
    
    <div class="verticalspacer"></div>
   </div>
   
   
  </div>
  <div class="preload_images">
   <img class="preload" src="images/u2087-17-r.png" alt=""/>
   <img class="preload" src="images/u2087-17-m.png" alt=""/>
   <img class="preload" src="images/u2087-17-fs.png" alt=""/>
  </div>
  <!-- JS includes -->
  <?php include 'footer.php' ?>
   </body>
</html>

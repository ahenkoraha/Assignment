<?php
ob_start();
$id = (int) $_GET['id'];
if ($id < 1)
{
	header('Location: forum.php');
	exit();
}
ob_end_clean();

include_once 'scripts/db_config.php';
	global $mysql_hostname, $mysql_dbname, $mysql_username,$mysql_password;
?>
<!DOCTYPE html>
<html class="html" lang="en-US">
   <?php
 require 'function.php';
 $pagename = 'topics.php'; 
  include 'head.php';
 ?>
 <body>
      </div>
       <?php include 'nav.php'; ?>
      </div>
<div class="lead alert-danger">
	<h1><strong>Replies</strong></h1>
</div>
<div class="col-md-8 col-lg-8">
<table border="1" cellpadding="4" width="100%" class="table table-hover">
<?php

$query1 =$mysqli->query("SELECT * FROM replies WHERE topicid = $id ORDER BY id ASC");
if ($query1){
	$query2 = $query1->num_rows;
}
else {
	$query2=0;
}

$query3 =$mysqli->query("SELECT * FROM topics WHERE id = $id");
if($query3){
	$output2 = $query3->fetch_assoc();
	echo '<tr><td>'.$output2['subject'].' - Posted by <strong>'.$output2['poster'].'</strong></td>';
	echo '<td>'.date('D-m-y G:i', $output2['date']).'</td></tr>';
	echo '<tr><td colspan="2">'.$output2['message'].'</td></tr>';
	echo '<tr><td colspan="2">&nbsp;</td></tr>';
	if ($query2 == 0)
		echo '<td colspan="2">No Replies</td>';
	else
	{
		if($query1){
			while ($output = $query1->fetch_assoc())
			{
				echo '<tr><td>'.$output['subject'].'</td><td>'.date('d-m-y G:i', $output['date']).'</td></tr>';
				echo '<tr><td colspan="2">'.$output['message'].'<br /><strong>Posted by '.$output['poster'].'</strong></td></tr>';
			}
		}
	}
}
?>
</table>
</div>
<hr />
<div class="container col-md-4 col-lg-4">
<form class="form-horizontal" name="form1" id="form1" method="post" action="forum_post.php?type=replies&id=<? echo $id; ?>">
<h3 class="lead"><strong>Add Reply</strong></h3>
<div class=" form-group row formitem">
<label class="form-control-label">Reply Subject:</label>
<input class="form-control " name="subject" id="subject" type="text" placeholder="Reply Subject" value="<?php  if($query3) { echo $output2['subject'];} else {
	echo '';
} ?>" />
</div>
<div class=" form-group row formitem">
	<label class="form-control-label">Message:</label>
<textarea class="form-control " name="message" id="message" cols="30" rows="3" placeholder="Message"></textarea></div>
<div class=" form-group row formitem">
	<label class="form-control-label">Posting by:</label>
<input class="form-control " readonly="readonly" name="poster" id="poster" type="text" placeholder="Username" value="<?php  if( isset( $_SESSION['user_name'] ) ){ echo $_SESSION['user_name'];} else {
	echo '';
} ?>" /></div>
<div class=" form-group row">
<input class="btn btn-danger" type="submit" name="submit" id="submit" value="Submit" /></div>
</form>
</div>
</body>
</html>
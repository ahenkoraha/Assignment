<?php
ob_start();
$id = (int) $_GET['id'];
$type = $_GET['type'];
if ($id < 1 || ($type != 'replies' && $type != 'topics'))
{
	header('Location: forum.php');
	exit();
}
ob_end_clean();
include_once 'scripts/db_config.php';
	global $mysql_hostname, $mysql_dbname, $mysql_username,$mysql_password;
?>
<!DOCTYPE html>
<html class="html" lang="en-US">
   <?php
 require 'function.php';
 $pagename = 'topics.php'; 
  include 'head.php';
 ?>
 <body>
      </div>
       <?php include 'nav.php'; ?>
      </div>
<?php
function clear($message)
{
	if(!get_magic_quotes_gpc())
		$message = addslashes($message);
	$message = strip_tags($message);
	$message = htmlentities($message);
	return trim($message);
}
if ($_POST['submit'])
{
	
	$message = clear($_POST['message']);
	$subject = clear($_POST['subject']);
	$poster = clear($_POST['poster']);
	$date = mktime();
	if($type == 'topics')
	{
		$mquery = $mysqli->query("SELECT topics FROM main WHERE id = '$id'");
		if($mquery){
			$query = $mquery->fetch_assoc();
			$topics = $query['topics'] + 1;
			$mysqli->query("UPDATE main SET topics = '$topics', lastposter = '$poster', lastpostdate = '$date' WHERE id = '$id'");
			$mysqli->query("INSERT INTO topics (id , forumid , message , subject, poster, date, lastposter, lastpostdate, replies) VALUES ('', '$id', '$message', '$subject','$poster', '$date', '', '', '0')");
			echo '<div class="alert alert-warning">Topic Posted.<a href="topics.php?id='.$id.'">View Topic</a></div>';
		}
	}
	else
	{
		$mquery = $mysqli->query("SELECT replies, forumid FROM topics WHERE id = '$id'");
		if($mquery){
		$query = $mquery->fetch_assoc();
			$replies = $query['replies'] + 1;
			$id2 =  $query['forumid'];
			$mysqli->query("UPDATE topics SET replies = '$replies', lastposter = '$poster', lastpostdate = '$date' WHERE id = '$id'");
			$mquery2 = $mysqli->query("SELECT replies FROM main WHERE id = '$id2'");
			if($mquery2){
				$query = $mquery2->fetch_array();
				$replies = $query['replies'] + 1;
				$mysqli->query("UPDATE main SET replies = '$replies', lastposter = '$poster', lastpostdate = '$date' WHERE id = '$id2'");
				$mysqli->query("INSERT INTO replies (id , topicid, message, subject, poster, date) VALUES ('', '$id', '$message', '$subject','$poster', '$date')");
				echo '<div class="alert alert-warning">Reply Posted.<a href="replies.php?id='.$id.'">View Reply</a></div>';
			}
		}
	}
}
?>
</body>
</html>
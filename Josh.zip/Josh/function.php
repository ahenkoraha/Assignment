<?php
    function get_css($page)
    {
        if($page =='index.php')
        {
            echo '<link rel="stylesheet" type="text/css" href="css/index.css" id="pagesheet"/>';
        }
        if($page =='models.php')
        {
            echo '<link rel="stylesheet" type="text/css" href="css/models.css" id="pagesheet"/>';
        }
         if($page =='veyron.php')
        {
            echo '<link rel="stylesheet" type="text/css" href="css/veyron.css" id="pagesheet"/>';
        }
         if($page =='sign-up.php')
        {
            echo '<link rel="stylesheet" type="text/css" href="css/sign-up.css" id="pagesheet"/>';
        }
         if($page =='products.php')
        {
            echo '<link rel="stylesheet" type="text/css" href="css/product.css" id="pagesheet"/>';
        }
         if($page =='forum.php')
        {
            echo '<link rel="stylesheet" type="text/css" href="css/product.css" id="pagesheet"/>';
        }
         if($page =='topics.php')
        {
            echo '<link rel="stylesheet" type="text/css" href="css/product.css" id="pagesheet"/>';
        }
         if($page =='replies.php')
        {
            echo '<link rel="stylesheet" type="text/css" href="css/product.css" id="pagesheet"/>';
        }
    }
    
    function get_title($page)
    {
        if($page =='index.php')
            echo 'Home';
        if($page =='models.php')
        echo 'Models';
         if($page =='veyron.php')
        echo 'Veyron';
         if($page =='sign-up.php')
        echo 'Sign Up';
        if($page =='products.php')
        echo 'Products';
        if($page =='product_detail.php')
        echo 'Product Detail';
        if($page =='forum.php')
        echo 'Forum';
    }

?>
<!DOCTYPE html>
<html class="html" lang="en-US">
  <?php 
  require 'function.php';
  $pagename = 'veyron.php';
  include 'head.php';
 ?>
 <body>

  <div class="clearfix" id="page"><!-- column -->
   <div class="position_content" id="page_position_content">
    <div class="browser_width colelem" id="u2059-bw">
     <div id="u2059"><!-- simple frame --></div>
    </div>
    <div class="browser_width colelem" id="u1126-bw">
    
       <!-- /m_editable -->
              <?php
              
              include 'nav.php'; 
              ?>

    </div>
    <div class="clearfix colelem" id="pu2185"><!-- group -->
     <div class="clearfix grpelem" id="u2185"><!-- group -->
      <div class="clearfix grpelem" id="ppu2186"><!-- group -->
       <div class="grpelem" id="pu2186"><!-- inclusion -->
        <div id="u2186"><!-- simple frame --></div>
        <div class="clearfix" id="pu2189-4"><!-- group -->
         <!-- m_editable region-id="editable-static-tag-U2189" template="veyron.html" data-type="html" data-ice-options="disableImageResize,link" -->
         <div class="clearfix grpelem" id="u2189-4" data-muse-uid="U2189" data-muse-type="txt_frame"><!-- content -->
          <p id="u2189-2">Since its launch in 2005, the Bugatti Veyron has been regarded as a supercar of superlative quality. It was a real challenge for developers to fulfil the specifications that the new supercar was supposed to meet: over 1,000 hp, a top speed of over 400 km/h and the ability to accelerate from 0 to 100 in under three seconds. Even experts thought it was impossible to achieve these performance specs on the road. But that was not all.</p>
         </div>
         <!-- /m_editable -->
        </div>
       </div>
       <!-- m_editable region-id="editable-static-tag-U2187" template="veyron.html" data-type="image" -->
       <div class="clip_frame grpelem" id="u2187" data-muse-uid="U2187" data-muse-type="img_frame"><!-- image -->
        <img class="block" id="u2187_img" src="images/csm_03_bugatti-vgt_racing_web_e388ab7263.jpg" alt="" width="538" height="304" data-muse-src="images/csm_03_bugatti-vgt_racing_web_e388ab7263.jpg"/>
       </div>
       <!-- /m_editable -->
      </div>
      <div class="clearfix grpelem" id="pu2195"><!-- column -->
       <div class="colelem" id="u2195"><!-- simple frame --></div>
       <div class="colelem" id="u2192"><!-- simple frame --></div>
      </div>
     </div>
     <!-- m_editable region-id="editable-static-tag-U2193" template="veyron.html" data-type="html" data-ice-options="disableImageResize,link" -->
     <div class="clearfix grpelem" id="u2193-45" data-muse-uid="U2193" data-muse-type="txt_frame"><!-- content -->
      <p>Cylinder capacity 7 993 cm³</p>
      <p id="u2193-3">&nbsp;</p>
      <p>Power output 736 kW ( 1 001 HP) at 6 000 rpm</p>
      <p id="u2193-6">&nbsp;</p>
      <p>Max. torque 1 250 Nm at 2 200-5 500 rpm</p>
      <p id="u2193-9">&nbsp;</p>
      <p>Gearbox 7-speed DSG</p>
      <p id="u2193-12">&nbsp;</p>
      <p>Top speed 407 km/h</p>
      <p id="u2193-15">&nbsp;</p>
      <p>ACCELERATION</p>
      <p>0 – 100 km/h 2.5 sec 0 - 100 km/h</p>
      <p>0 – 200 km/h 7.3 sec 0 - 200 km/h</p>
      <p>0 – 300 km/h 16.7 sec 0 - 300 km/h</p>
      <p id="u2193-24">&nbsp;</p>
      <p>CO2-EMISSION</p>
      <p>In town 999 g/km</p>
      <p>Extra-urban 373 g/km</p>
      <p>Combined 596 g/km</p>
      <p id="u2193-33">&nbsp;</p>
      <p>FUEL CONSUMPTION</p>
      <p>In town 41.9 l</p>
      <p>Out of town 15.6 l</p>
      <p>Combined 24.9 l</p>
      <p>Fuel type Super unleaded 98 RON/ROZ</p>
     </div>
     <!-- /m_editable -->
     <!-- m_editable region-id="editable-static-tag-U2196" template="veyron.html" data-type="html" data-ice-options="disableImageResize,link" -->
     <div class="clearfix grpelem" id="u2196-4" data-muse-uid="U2196" data-muse-type="txt_frame"><!-- content -->
      <p>TECHNICAL DETAILS</p>
     </div>
     <!-- /m_editable -->
    </div>
    <div class="verticalspacer"></div>
   </div>
  </div>
  <!-- JS includes -->
  <?php include 'footer.php' ?>
   </body>
</html>

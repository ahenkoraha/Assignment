<!DOCTYPE html>
<html class="html" lang="en-US">
  <?php 
  require 'function.php';
  $pagename = 'models.php';
  include 'head.php';
 ?>
 <body>

  <div class="clearfix" id="page"><!-- column -->
   <div class="position_content" id="page_position_content">
    <div class="browser_width colelem" id="u2059-bw">
     <div id="u2059"><!-- simple frame --></div>
    </div>
    <div class="browser_width colelem" id="u1126-bw">
     
       <!-- /m_editable -->
              <?php 
              include 'nav.php'; ?>

    </div>
    <div class="clearfix colelem" id="pu2180"><!-- group -->
     <div class="clearfix grpelem" id="u2180"><!-- group -->
      <!-- m_editable region-id="editable-static-tag-U2142" template="models.html" data-type="image" data-ice-options="clickable" data-ice-editable="link" -->
      <a class="nonblock nontext clip_frame grpelem" id="u2142" href="#" data-href="page:U1134" data-muse-uid="U2142" data-muse-type="img_frame"><!-- image --><img class="block" id="u2142_img" src="images/bugatti-vision-gt-iaa-4358x202.jpg" alt="" width="358" height="201" data-muse-src="images/bugatti-vision-gt-iaa-4358x202.jpg"/></a>
      <!-- /m_editable -->
      <div class="grpelem" id="pu2160"><!-- inclusion -->
       <!-- m_editable region-id="editable-static-tag-U2160" template="models.html" data-type="html" data-ice-options="clickable" data-ice-editable="link" -->
       <a class="nonblock nontext" id="u2160" href="#" data-href="page:U1134" data-muse-uid="U2160"><!-- simple frame --></a>
       <!-- /m_editable -->
       <div class="clearfix" id="pu2161-4"><!-- group -->
        <!-- m_editable region-id="editable-static-tag-U2161" template="models.html" data-type="html" data-ice-options="disableImageResize,link,clickable" data-ice-editable="link" -->
        <a class="nonblock nontext clearfix grpelem" id="u2161-4" href="#" data-href="page:U1134" data-muse-uid="U2161" data-muse-type="txt_frame"><!-- content --><p>GRAND SPORT</p></a>
        <!-- /m_editable -->
       </div>
      </div>
     </div>
     <div class="clearfix grpelem" id="u2181"><!-- group -->
      <!-- m_editable region-id="editable-static-tag-U2163" template="models.html" data-type="image" data-ice-options="clickable" data-ice-editable="link" -->
      <a class="nonblock nontext clip_frame grpelem" id="u2163" href="#" data-href="page:U1134" data-muse-uid="U2163" data-muse-type="img_frame"><!-- image --><img class="block" id="u2163_img" src="images/csm_03_bugatti-vgt_racing_web_e388ab7263.jpg" alt="" width="357" height="201" data-muse-src="images/csm_03_bugatti-vgt_racing_web_e388ab7263.jpg"/></a>
      <!-- /m_editable -->
      <div class="grpelem" id="pu2162"><!-- inclusion -->
       <!-- m_editable region-id="editable-static-tag-U2162" template="models.html" data-type="html" data-ice-options="clickable" data-ice-editable="link" -->
       <a class="nonblock nontext" id="u2162" href="#" data-href="page:U1134" data-muse-uid="U2162"><!-- simple frame --></a>
       <!-- /m_editable -->
       <div class="clearfix" id="pu2166-4"><!-- group -->
        <!-- m_editable region-id="editable-static-tag-U2166" template="models.html" data-type="html" data-ice-options="disableImageResize,link,clickable" data-ice-editable="link" -->
        <a class="nonblock nontext clearfix grpelem" id="u2166-4" href="#" data-href="page:U1134" data-muse-uid="U2166" data-muse-type="txt_frame"><!-- content --><p>VEYRON</p></a>
        <!-- /m_editable -->
       </div>
      </div>
     </div>
    </div>
    <div class="clearfix colelem" id="pu2182"><!-- group -->
     <div class="clearfix grpelem" id="u2182"><!-- group -->
      <!-- m_editable region-id="editable-static-tag-U2168" template="models.html" data-type="image" data-ice-options="clickable" data-ice-editable="link" -->
      <a class="nonblock nontext clip_frame clearfix grpelem" id="u2168" href="#" data-href="page:U1134" data-muse-uid="U2168" data-muse-type="img_frame"><!-- image --><div id="u2168_clip"><img class="position_content" id="u2168_img" src="images/th.jpg" alt="" width="358" height="224" data-muse-src="images/th.jpg"/></div></a>
      <!-- /m_editable -->
      <div class="grpelem" id="pu2167"><!-- inclusion -->
       <!-- m_editable region-id="editable-static-tag-U2167" template="models.html" data-type="html" data-ice-options="clickable" data-ice-editable="link" -->
       <a class="nonblock nontext" id="u2167" href="#" data-href="page:U1134" data-muse-uid="U2167"><!-- simple frame --></a>
       <!-- /m_editable -->
       <div class="clearfix" id="pu2172-4"><!-- group -->
        <!-- m_editable region-id="editable-static-tag-U2172" template="models.html" data-type="html" data-ice-options="disableImageResize,link,clickable" data-ice-editable="link" -->
        <a class="nonblock nontext clearfix grpelem" id="u2172-4" href="#" data-href="page:U1134" data-muse-uid="U2172" data-muse-type="txt_frame"><!-- content --><p>VITESSE</p></a>
        <!-- /m_editable -->
       </div>
      </div>
     </div>
     <div class="clearfix grpelem" id="u2183"><!-- group -->
      <!-- m_editable region-id="editable-static-tag-U2173" template="models.html" data-type="image" data-ice-options="clickable" data-ice-editable="link" -->
      <a class="nonblock nontext clip_frame grpelem" id="u2173" href="#" data-href="page:U1134" data-muse-uid="U2173" data-muse-type="img_frame"><!-- image --><img class="block" id="u2173_img" src="images/02_bugatti-vgt_photo_ext_web-932x524.jpg" alt="" width="358" height="201" data-muse-src="images/02_bugatti-vgt_photo_ext_web-932x524.jpg"/></a>
      <!-- /m_editable -->
      <div class="grpelem" id="pu2171"><!-- inclusion -->
       <!-- m_editable region-id="editable-static-tag-U2171" template="models.html" data-type="html" data-ice-options="clickable" data-ice-editable="link" -->
       <a class="nonblock nontext" id="u2171" href="#" data-href="page:U1134" data-muse-uid="U2171"><!-- simple frame --></a>
       <!-- /m_editable -->
       <div class="clearfix" id="pu2176-4"><!-- group -->
        <!-- m_editable region-id="editable-static-tag-U2176" template="models.html" data-type="html" data-ice-options="disableImageResize,link,clickable" data-ice-editable="link" -->
        <a class="nonblock nontext clearfix grpelem" id="u2176-4" href="#" data-href="page:U1134" data-muse-uid="U2176" data-muse-type="txt_frame"><!-- content --><p>SUPER SPORT</p></a>
        <!-- /m_editable -->
       </div>
      </div>
     </div>
    </div>
    <div class="verticalspacer"></div>
   </div>
  </div>
  <!-- JS includes -->
  <?php include 'footer.php' ?>
   </body>
</html>
